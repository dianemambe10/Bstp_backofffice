/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CustomPipePipe } from '../custom-pipe.pipe';

describe('Pipe: CustomPipee', () => {
  it('create an instance', () => {
    let pipe = new CustomPipePipe();
    expect(pipe).toBeTruthy();
  });
});
