export class Payement {
  id?: number;
  reference?: any;
  amount?: any;
  transaction_time?: any;
  gateway_transaction_code?: any;
  remarks?: any;
  status?: any;
  mode?: any;
  company?: any;
  payment_mode?: any;
}
