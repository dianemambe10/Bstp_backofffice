import { an } from "@fullcalendar/core/internal-common";
import {Prefecture} from "./prefecture.model";

export class Institut {
  id?: any;
  name?: any;
  status?: any;
  thematiques?: any;
  state?: any;
}
