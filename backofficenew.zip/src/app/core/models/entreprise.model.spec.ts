import { Entreprise } from './entreprise.model';

describe('Entreprise', () => {
  it('should create an instance', () => {
    expect(new Entreprise()).toBeTruthy();
  });
});
