import { Acheteur } from './acheteur';

describe('Acheteur', () => {
  it('should create an instance', () => {
    expect(new Acheteur()).toBeTruthy();
  });
});
