import { an } from "@fullcalendar/core/internal-common";
import {Prefecture} from "./prefecture.model";

export class Contrat {
  id?: any;
  bstp_member?: any;
  company?: any;
  observation?: any;
  other_company?: any;
  signature_date?: any;
  amount?: any;
  request?: any;
  description?: any;
}
