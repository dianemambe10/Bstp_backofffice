export class Thematique {
  id?: number;
  name?: string;
}
