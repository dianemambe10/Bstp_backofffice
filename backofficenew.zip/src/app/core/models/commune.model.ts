import {Prefecture} from "./prefecture.model";

export class Commune {
  id?: number;
  name?: string;
  prefecture?: Prefecture;
}
