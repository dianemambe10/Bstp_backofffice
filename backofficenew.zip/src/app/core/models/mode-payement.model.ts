export class ModePayement {
  id?: number;
  name?: string;
  description?: string;
  instructions?: string;
}
