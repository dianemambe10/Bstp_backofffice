export class TypeSociete {
  id?: number;
  name?: string;
  code?: any;
}
