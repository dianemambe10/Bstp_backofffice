export class Documents {
      firstname?: String;
      name?: String;
      civilite?: String;
      email?: String;
      phoneNumber?: String;
      role_dans_lentreprise?: String;
}

