export class TypeDemande {
  id?: number;
  name?: string;
}
