export interface ListModel {
  id?: any;
  bstp_member?: any;
  other_company?: any;
  amount?: any;
  description?: any;
  signature_date?: any;
  observation?: any;
  request?: any;
  company?: any;
  action_user?: any;
}