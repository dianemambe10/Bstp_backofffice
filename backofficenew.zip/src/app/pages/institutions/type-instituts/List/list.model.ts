export interface ListModel {
  id?: any;
  name?: any;
}
