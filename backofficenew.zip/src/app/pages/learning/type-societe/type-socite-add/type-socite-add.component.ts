import { Component } from '@angular/core';

@Component({
  selector: 'app-type-socite-add',
  templateUrl: './type-socite-add.component.html',
  styleUrls: ['./type-socite-add.component.scss']
})
export class TypeSociteAddComponent {

}
