export interface GridModel {
  id?: any;
  category?: any;
  img?: any;
  name?: any;
  instructor?: any;
  lessons?: any;
  duration?: any;
  students?: any;
  profile?: any;
  status?: any;
  fees?: any;
  color?: any;
}