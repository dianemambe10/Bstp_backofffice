export interface CategoryModel {
  id?: any;
  img?: any;
  name?: any;
  course?: any;
}