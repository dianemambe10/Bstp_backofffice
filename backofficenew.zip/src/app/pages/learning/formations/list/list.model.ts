export interface ListModel {
  id?: any;
  title?: any;
  description?: any;
  thematiques?: any;
  date_publication?: any;
  date_expiration?: any;
  status?: any;
  etat?: any;
  slug?: any;
  mode?: any;
  centre?: any;

}
