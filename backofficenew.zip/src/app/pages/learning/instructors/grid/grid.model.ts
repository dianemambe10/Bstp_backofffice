export interface InstructorGridModel {
  id?: any;
  img?: any;
  name?: any;
  total_course?: any;
  email?: any;
  designation?: any;
  contact?: any;
  rating?: any;
  status?: any;
}