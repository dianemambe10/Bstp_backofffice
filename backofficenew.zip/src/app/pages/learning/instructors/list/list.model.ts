export interface InstructorListModel {
  id?: any;
  img?: any;
  name?: any;
  total_course?: any;
  email?: any;
  experience?: any;
  students?: any;
  contact?: any;
  rating?: any;
  status?: any;
}