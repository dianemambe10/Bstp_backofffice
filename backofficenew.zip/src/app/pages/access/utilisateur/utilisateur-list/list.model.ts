export interface ListModel {
  id?: any;
  email?: any;
  avatar?: any;
  first_name?: any;
  last_name?: any;
  is_active?: any;
  phone_number?: any;
  gender?: any;
  role_id?: any;
  username?: any;
  status?: any;
}
