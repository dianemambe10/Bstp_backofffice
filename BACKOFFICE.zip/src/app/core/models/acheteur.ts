export class Acheteur {

  
}
