export class Demandeur {
  last_name?: String;
  first_name?: String;
  username?: String;
  gender?: String;
  email?: String;
  date_of_birth?: String;
  role_dans_lentreprise?: String;
  id?: any;
  avatar?: any;
  is_active?: boolean;
  phone_number?: any;
  role_id?: any;
  status?: any;
  last_login?: any;
}

