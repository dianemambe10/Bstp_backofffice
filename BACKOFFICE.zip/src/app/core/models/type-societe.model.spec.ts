import { TypeSociete } from './type-societe.model';

describe('TypeSociete', () => {
  it('should create an instance', () => {
    expect(new TypeSociete()).toBeTruthy();
  });
});
