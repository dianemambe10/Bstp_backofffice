export class Actionnaire {
  id?: any;
  last_name?: any;
  first_name?: any;
  date_of_birth?: any;
  gender?: any;
  phone_number?: any;
  email?: any;
  role?: any;
  username?: any;
  associate_percentage?: any;
  nationality?: any;
}
