export class Role {
  id?: number;
  name?: string;
  code_name?: string;
}
