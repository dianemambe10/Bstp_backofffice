export class DomaineActivite {
  id?: number;
  name?: string;
  code_africa?: string;
  code_apip?: string;
}
