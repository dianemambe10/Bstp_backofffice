import { Demandeur } from './demandeur.model';

describe('Demandeur', () => {
  it('should create an instance', () => {
    expect(new Demandeur()).toBeTruthy();
  });
});
