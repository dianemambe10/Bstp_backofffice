import {Region} from "./region.model";

export class Prefecture {
  id?: number;
  name?: string;
  region?: Region;
}
