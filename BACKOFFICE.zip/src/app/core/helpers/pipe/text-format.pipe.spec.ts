/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TextFormatPipe } from './text-format.pipe';

describe('Pipe: TextFormate', () => {
  it('create an instance', () => {
    let pipe = new TextFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
