import { Component } from '@angular/core';

@Component({
  selector: 'app-demande-grid',
  templateUrl: './demande-grid.component.html',
  styleUrls: ['./demande-grid.component.scss']
})
export class DemandeGridComponent {

}
