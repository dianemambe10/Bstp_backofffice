export interface ListModel {
  reference?: any;
  amount?: any;
  transaction_time?: any;
  gateway_transaction_code?: any;
  remarks?: any;
  status?: any;
  mode?: any;
  payment_mode?: any;
  company?: any;

 

}
