import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NiveaPaiementRoutingModule } from './nivea-paiement-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NiveaPaiementRoutingModule
  ]
})
export class NiveaPaiementModule { }
