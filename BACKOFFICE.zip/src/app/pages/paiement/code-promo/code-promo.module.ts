import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CodePromoRoutingModule } from './code-promo-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CodePromoRoutingModule
  ]
})
export class CodePromoModule { }
