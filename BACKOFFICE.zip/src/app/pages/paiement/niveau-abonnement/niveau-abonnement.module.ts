import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NiveauAbonnementRoutingModule } from './niveau-abonnement-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NiveauAbonnementRoutingModule
  ]
})
export class NiveauAbonnementModule { }
