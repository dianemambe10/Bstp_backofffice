export interface InstructorModel {
    id?: any,
    img?: any;
    name?: any,
    course?: any,
    rate?: any;
}

export interface CourseModel {
    id?: any,
    img?: any,
    name?: any,
    category?: any,
    instructor?: any,
    lession?: any,
    duration?: any
    fees?: any
    status?: any
    rating?: any
}