export interface PropertyModel {
    id?: any,
    type?: any;
    img?: any,
    name?: any,
    address?: any;
    agentname?: any,
    price?: any,
    status?: any
}
