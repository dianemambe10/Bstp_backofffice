export interface ListModel {
  id?: any;
  libelle?: any;
}
