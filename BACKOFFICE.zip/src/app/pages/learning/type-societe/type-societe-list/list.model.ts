export interface ListModel {
  id?: any;
  name?: any;
  code?: any;
}
