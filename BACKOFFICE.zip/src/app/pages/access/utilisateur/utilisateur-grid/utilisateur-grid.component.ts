import { Component } from '@angular/core';

@Component({
  selector: 'app-utilisateur-grid',
  templateUrl: './utilisateur-grid.component.html',
  styleUrls: ['./utilisateur-grid.component.scss']
})
export class UtilisateurGridComponent {

}
