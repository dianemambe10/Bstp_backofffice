export interface ListModel {
  id?: any;
  category?: any;
  img?: any;
  name?: any;
  instructor?: any;
  lessons?: any;
  duration?: any;
  students?: any;
  fees?: any;
  rating?: any;
  status?: any;
}